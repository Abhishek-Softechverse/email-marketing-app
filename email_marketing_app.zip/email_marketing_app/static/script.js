// static/script.js
// Put this file in /static/script.js
// Globals (must be first)
var accounts = [];
var activeCampaigns = {}; // client-side cache of run-time campaign states
var socket = null;

// Initialize socket after DOM load
document.addEventListener('DOMContentLoaded', () => {
    // connect socket.io (served by Flask-SocketIO at /socket.io/)
    socket = io();

    socket.on('progress_update', (data) => {
        // progress message contains: campaign_id, progress, current, total, sent, errors, status
        updateCampaignProgress(data);
    });

    socket.on('sending_complete', (data) => {
        showNotification("✅ Campaign Complete", "success", `Sent: ${data.sent}, Errors: ${data.errors}, Success Rate: ${data.success_rate.toFixed(1)}%`);
        activeCampaigns[data.campaign_id] = { status: 'completed', sent: data.sent, errors: data.errors };
        updateCampaignList();
    });

    socket.on('sending_error', (data) => {
        showNotification("❌ Error", "danger", data.error || "Unknown error");
        activeCampaigns[data.campaign_id] = { status: 'error', error: data.error };
        updateCampaignList();
    });

    socket.on('email_opened', (data) => {
        // data: { tracking_id, opened_at, ... maybe campaign_id if backend emits }
        // We allow server to optionally provide campaign_id inside payload.
        if (data.campaign_id) {
            // increment open count for campaign in UI cache
            const id = data.campaign_id;
            if (!activeCampaigns[id]) activeCampaigns[id] = {};
            activeCampaigns[id].opens = (activeCampaigns[id].opens || 0) + 1;
            updateCampaignList();
        }
        showNotification("📬 Email Opened", "info", `Tracking ID: ${data.tracking_id || 'n/a'}`);
    });

    updateCampaignList();
});

// ---- ACCOUNT MANAGEMENT ----
function addAccount() {
    const email = document.getElementById('account-email').value.trim();
    const password = document.getElementById('account-password').value.trim();
    const smtpServer = document.getElementById('smtp-server').value.trim();
    const smtpPort = document.getElementById('smtp-port').value.trim();
    const useSsl = document.getElementById('use-ssl').checked;
    const maxPerMinute = parseInt(document.getElementById('max-per-minute').value) || 60;

    if (!email || !password) {
        showNotification('❌ Error', 'danger', 'Please fill in email and password fields');
        return;
    }
    if (!isValidEmail(email)) {
        showNotification('❌ Invalid Email', 'danger', 'Please enter a valid email address');
        return;
    }
    if (accounts.some(acc => acc.email === email)) {
        showNotification('❌ Duplicate Account', 'warning', 'This email account is already added');
        return;
    }

    const account = {
        email: email,
        password: password,
        smtp_server: smtpServer || 'smtp.example.com',
        smtp_port: parseInt(smtpPort) || (useSsl ? 465 : 587),
        use_ssl: Boolean(useSsl),
        max_per_minute: maxPerMinute
    };

    accounts.push(account);
    updateAccountsList();
    clearAccountForm();
    showNotification('✅ Account Added', 'success', `Added ${email} successfully`);
}

function updateAccountsList() {
    const list = document.getElementById('accounts-list');
    if (!list) return;
    list.innerHTML = '';
    accounts.forEach((acc, i) => {
        const li = document.createElement('li');
        li.className = "list-group-item d-flex justify-content-between align-items-center";
        li.innerHTML = `
            <div>
                <strong>${escapeHtml(acc.email)}</strong>
                <div class="small text-muted">${escapeHtml(acc.smtp_server)}:${acc.smtp_port} | SSL: ${acc.use_ssl ? 'Yes' : 'No'} | ${acc.max_per_minute}/min</div>
            </div>
            <div>
                <button class="btn btn-sm btn-danger" onclick="removeAccount(${i})">Remove</button>
            </div>
        `;
        list.appendChild(li);
    });
}

function removeAccount(index) {
    accounts.splice(index, 1);
    updateAccountsList();
}

function clearAccountForm() {
    document.getElementById('account-email').value = '';
    document.getElementById('account-password').value = '';
    document.getElementById('smtp-server').value = '';
    document.getElementById('smtp-port').value = '';
    document.getElementById('use-ssl').checked = false;
    document.getElementById('max-per-minute').value = '60';
}

// ---- VALIDATORS ----
function isValidEmail(email) {
    const re = /^[^@\s]+@[^@\s]+\.[^@\s]+$/;
    return re.test(email);
}

// ---- CAMPAIGN ----
function startSending() {
    const subject = document.getElementById('subject').value.trim();
    const body = document.getElementById('body').value.trim();
    const fileInput = document.getElementById('email-file');
    const rotateToggle = document.getElementById('rotate-toggle').checked;
    const throttleToggle = true; // always true for safety

    if (!subject || !body) {
        showNotification('❌ Error', 'danger', 'Subject and Body required');
        return;
    }
    if (accounts.length === 0) {
        showNotification('❌ Error', 'danger', 'Add at least one account');
        return;
    }
    if (!fileInput.files.length) {
        showNotification('❌ Error', 'danger', 'Upload an email list file');
        return;
    }

    // Minimal anti-spam check: warn user if total recipients is very large and throttle low
    const file = fileInput.files[0];
    if (file.size > 5 * 1024 * 1024) {
        // warn about big file (optional)
        showNotification('⚠️ Large file', 'warning', 'Large recipient files may take time to process.');
    }

    const formData = new FormData();
    formData.append('file', file);
    formData.append('subject', subject);
    formData.append('body', body);
    formData.append('accounts', JSON.stringify(accounts));
    formData.append('rotate', rotateToggle ? 'true' : 'false');
    formData.append('throttle', throttleToggle ? 'true' : 'false');

    const attachments = document.getElementById('attachments').files;
    for (let i = 0; i < attachments.length; i++) {
        formData.append('attachments', attachments[i]);
    }

    showNotification("🚀 Sending Started", "info", "Emails are being processed...");

    fetch('/send-emails', {
        method: 'POST',
        body: formData
    }).then(r => r.json()).then(res => {
        if (res.success) {
            showNotification("✅ Campaign Launched", "success", `Campaign ID: ${res.campaign_id}`);
            // store initial campaign info
            activeCampaigns[res.campaign_id] = { status: 'running', sent: 0, errors: 0, progress: 0, subject: subject };
            updateCampaignList();
        } else {
            showNotification("❌ Error", "danger", res.error || "Failed to start");
        }
    }).catch(err => {
        showNotification("❌ Error", "danger", err.message || "Network error");
    });
}

function stopCampaign(campaignId) {
    if (!campaignId) return;
    if (!confirm("Stop this campaign? This will attempt to halt sending immediately.")) return;
    fetch('/stop-campaign', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({ campaign_id: campaignId })
    }).then(r => r.json()).then(res => {
        if (res.success) {
            showNotification('🛑 Campaign Stopped', 'info', `Campaign ${campaignId} stopped.`);
            activeCampaigns[campaignId] = activeCampaigns[campaignId] || {};
            activeCampaigns[campaignId].status = 'stopped';
            updateCampaignList();
        } else {
            showNotification('❌ Error', 'danger', res.error || 'Failed to stop');
        }
    }).catch(err => {
        showNotification('❌ Error', 'danger', err.message);
    });
}

function viewCampaignLogs(campaignId) {
    if (!campaignId) return;
    fetch(`/campaign-logs?campaign_id=${encodeURIComponent(campaignId)}`)
        .then(r => r.json())
        .then(res => {
            if (res.success) {
                showLogsModal(campaignId, res.logs || []);
            } else {
                showNotification('❌ Error', 'danger', res.error || 'Could not fetch logs');
            }
        })
        .catch(err => showNotification('❌ Error', 'danger', err.message));
}

function testSmtpConnections() {
    if (accounts.length === 0) {
        showNotification("❌ Error", "danger", "No accounts to test");
        return;
    }
    const formData = new FormData();
    formData.append('accounts', JSON.stringify(accounts));

    fetch('/test-smtp', {
        method: 'POST',
        body: formData
    }).then(r => r.json()).then(res => {
        if (res.success) {
            res.results.forEach(r => {
                if (r.success) {
                    showNotification("✅ SMTP OK", "success", `${r.email}: ${r.message}`);
                } else {
                    showNotification("❌ SMTP Failed", "danger", `${r.email}: ${r.message}`);
                }
            });
        } else {
            showNotification("❌ Error", "danger", res.error);
        }
    }).catch(err => {
        showNotification("❌ Error", "danger", err.message);
    });
}

// ---- UI HELPERS ----
function updateCampaignProgress(data) {
    const id = data.campaign_id;
    activeCampaigns[id] = activeCampaigns[id] || {};
    activeCampaigns[id].progress = data.progress;
    activeCampaigns[id].sent = data.sent;
    activeCampaigns[id].errors = data.errors;
    activeCampaigns[id].status = 'running';
    // if server includes subject or totals, store them
    if (data.total) activeCampaigns[id].total = data.total;
    updateCampaignList();
    // update progressbar if this is the currently selected campaign
    const progressBar = document.getElementById('progress-bar');
    if (progressBar && typeof data.progress === 'number') {
        progressBar.style.width = `${data.progress}%`;
        progressBar.innerText = `${Math.round(data.progress)}%`;
    }
}

function updateCampaignList() {
    // fetch campaigns summary from server and render; also merge local activeCampaigns info
    fetch('/campaigns')
        .then(r => r.json())
        .then(res => {
            const tbody = document.getElementById('campaigns-table');
            if (!tbody) return;
            tbody.innerHTML = '';
            (res.campaigns || []).forEach(c => {
                // merge runtime data
                const runtime = activeCampaigns[c.id] || {};
                const status = runtime.status || c.status || 'unknown';
                const sent = runtime.sent != null ? runtime.sent : (c.sent || 0);
                const total = runtime.total != null ? runtime.total : (c.total || c.total_emails || 0);
                const opens = runtime.opens || 0;
                const progress = runtime.progress != null ? runtime.progress : (total ? Math.round((sent/total)*100) : 0);

                const row = document.createElement('tr');
                row.innerHTML = `
                    <td style="word-break:break-all">${escapeHtml(c.id)}</td>
                    <td>${escapeHtml(c.subject || '')}</td>
                    <td>${total}</td>
                    <td>${sent}</td>
                    <td>${escapeHtml(String(status))} ${opens ? `<br><small>Opens: ${opens}</small>` : ''}</td>
                    <td>${escapeHtml(c.created || '')}</td>
                    <td>
                        <div class="btn-group" role="group">
                            <button class="btn btn-sm btn-primary" onclick="viewCampaignLogs('${escapeJs(c.id)}')">Logs</button>
                            <button class="btn btn-sm btn-warning" onclick="stopCampaign('${escapeJs(c.id)}')" ${status!=='running' ? 'disabled' : ''}>Stop</button>
                        </div>
                        <div class="mt-1">
                            <div class="progress" style="height:6px">
                                <div class="progress-bar" role="progressbar" style="width:${progress}%"></div>
                            </div>
                        </div>
                    </td>
                `;
                tbody.appendChild(row);
            });
        })
        .catch(err => {
            console.error(err);
        });
}

function showLogsModal(campaignId, logs) {
    // build a simple modal-like overlay with logs
    let html = `<div class="p-3"><h5>Logs for ${escapeHtml(campaignId)}</h5><table class="table table-sm"><thead><tr><th>Email</th><th>Sent At</th><th>Opened</th><th>Opened At</th><th>Error</th></tr></thead><tbody>`;
    logs.forEach(l => {
        html += `<tr>
            <td>${escapeHtml(l.email || '')}</td>
            <td>${escapeHtml(l.sent_at || '')}</td>
            <td>${l.opened ? 'Yes' : 'No'}</td>
            <td>${escapeHtml(l.opened_at || '')}</td>
            <td>${escapeHtml(l.error_message || '')}</td>
        </tr>`;
    });
    html += `</tbody></table><button class="btn btn-secondary" onclick="closeLogsModal()">Close</button></div>`;

    let container = document.getElementById('logs-modal');
    if (!container) {
        container = document.createElement('div');
        container.id = 'logs-modal';
        container.style.position = 'fixed';
        container.style.left = '10%';
        container.style.top = '5%';
        container.style.width = '80%';
        container.style.height = '90%';
        container.style.background = 'white';
        container.style.zIndex = 9999;
        container.style.overflow = 'auto';
        container.style.boxShadow = '0 6px 24px rgba(0,0,0,0.3)';
        container.className = 'p-3';
        document.body.appendChild(container);
    }
    container.innerHTML = html;
}

function closeLogsModal() {
    const container = document.getElementById('logs-modal');
    if (container) container.remove();
}

// small utilities
function escapeHtml(unsafe) {
    if (!unsafe && unsafe !== 0) return '';
    return String(unsafe)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}
function escapeJs(s) {
    if (!s && s !== 0) return '';
    return String(s).replace(/'/g, "\\'").replace(/"/g, '\\"');
}

function showNotification(title, type, message) {
    const container = document.getElementById('notifications');
    if (!container) return;
    const alert = document.createElement('div');
    alert.className = `alert alert-${type} alert-dismissible fade show`;
    alert.innerHTML = `<strong>${escapeHtml(title)}</strong> ${escapeHtml(message)}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>`;
    container.appendChild(alert);
    setTimeout(() => {
        if (alert && alert.parentNode) alert.parentNode.removeChild(alert);
    }, 7000);
}
