# app.py - updated
from flask import Flask, render_template, request, jsonify, send_file
from flask_socketio import SocketIO, emit
import pandas as pd
import sqlite3
import smtplib
import ssl
import email as email_lib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email import encoders
import os
import uuid
import time
import threading
from datetime import datetime, timedelta
import re
import traceback
import logging
import queue
import concurrent.futures
from threading import Thread, Lock
import json

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = Flask(__name__)
app.config['SECRET_KEY'] = 'Assjj8ds5s5s5'
socketio = SocketIO(app, cors_allowed_origins="*", async_mode='threading')

# Global variables
email_queue = queue.Queue()
active_campaigns = {}
campaign_counter = 0

# Initialize database
def init_db():
    try:
        conn = sqlite3.connect('database.db')
        cursor = conn.cursor()
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS email_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                campaign_id TEXT,
                email TEXT NOT NULL,
                tracking_id TEXT UNIQUE,
                sent_at TIMESTAMP,
                opened BOOLEAN DEFAULT 0,
                opened_at TIMESTAMP,
                bounced BOOLEAN DEFAULT 0,
                replied BOOLEAN DEFAULT 0,
                error_message TEXT
            )
        ''')
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS campaigns (
                id TEXT PRIMARY KEY,
                subject TEXT,
                total_emails INTEGER,
                sent_emails INTEGER DEFAULT 0,
                created_at TIMESTAMP,
                completed_at TIMESTAMP,
                status TEXT DEFAULT 'running'
            )
        ''')
        conn.commit()
        conn.close()
        logger.info("Database initialized successfully")
    except Exception as e:
        logger.error(f"Database initialization failed: {str(e)}")

class SuperFastEmailSender:
    def __init__(self, campaign_id, throttle=True, rotate=True):
        self.campaign_id = campaign_id
        self.total_emails = 0
        self.sent_count = 0
        self.error_count = 0
        self.running = True
        self.throttle = throttle
        self.rotate = rotate

    def quick_validate_email(self, email):
        email = email.strip().lower()
        return bool(re.match(r'^[^@\s]+@[^@\s]+\.[^@\s]+$', email)) and len(email) < 255

    def _open_smtp(self, account_state, timeout=15):
        """
        Opens and returns a connected SMTP object appropriately (SSL or STARTTLS).
        account_state must include: smtp_server, smtp_port, email, password, use_ssl
        """
        server = None
        try:
            host = account_state['smtp_server']
            port = int(account_state.get('smtp_port') or 0)
            use_ssl = bool(account_state.get('use_ssl', False) or port == 465)

            if use_ssl:
                context = ssl.create_default_context()
                server = smtplib.SMTP_SSL(host, port, timeout=timeout, context=context)
                server.ehlo()
            else:
                server = smtplib.SMTP(host, port, timeout=timeout)
                server.ehlo()
                try:
                    server.starttls(context=ssl.create_default_context())
                    server.ehlo()
                except Exception as e:
                    # Not fatal — continue; some servers don't require starttls on custom ports
                    logger.debug(f"starttls failed or not required: {e}")

            # Login
            server.login(account_state['email'], account_state['password'])
            return server, None
        except smtplib.SMTPAuthenticationError as e:
            if server:
                try: server.quit()
                except: pass
            return None, "Authentication failed - check email/password or use app-password"
        except smtplib.SMTPConnectError:
            return None, "Cannot connect to SMTP server (connect error)"
        except Exception as e:
            if server:
                try: server.quit()
                except: pass
            return None, f"SMTP open error: {str(e)}"

    def test_smtp_connection(self, account):
        """
        Try both SSL and STARTTLS where appropriate and return a helpful message.
        """
        try:
            # try based on provided use_ssl or port first
            account_state = dict(account)
            account_state.setdefault('smtp_port', account_state.get('smtp_port', 587))
            account_state.setdefault('use_ssl', account_state.get('use_ssl', False) or int(account_state['smtp_port']) == 465)
            server, err = self._open_smtp(account_state, timeout=10)
            if server:
                server.quit()
                return True, "Connection successful (used recommended method)"
            else:
                # If first attempt failed and wasn't explicit, try opposite method to gather more info
                alt = dict(account_state)
                alt['use_ssl'] = not account_state['use_ssl']
                alt['smtp_port'] = 465 if not account_state['use_ssl'] else 587
                server2, err2 = self._open_smtp(alt, timeout=10)
                if server2:
                    server2.quit()
                    return True, f"Connection successful (using alternate method on port {alt['smtp_port']})"
                return False, err or err2 or "Unknown connection error"
        except Exception as e:
            return False, f"Test error: {str(e)}"

    def send_single_email_optimized(self, to_email, subject, body, account_state, attachments=None):
        """
        Sends a single email using the provided account_state (which includes throttle data).
        Returns (True, None) on success, (False, error_message) on failure.
        """
        try:
            # Throttling: ensure we don't exceed max_per_minute for this account
            if self.throttle:
                now = datetime.utcnow()
                max_per_minute = int(account_state.get('max_per_minute', 60) or 60)
                # Clean timestamps older than 60 seconds
                with account_state['lock']:
                    cutoff = now - timedelta(seconds=60)
                    account_state['sent_timestamps'] = [t for t in account_state['sent_timestamps'] if t > cutoff]
                    if len(account_state['sent_timestamps']) >= max_per_minute:
                        # Need to wait until we can send
                        oldest = min(account_state['sent_timestamps'])
                        sleep_for = (oldest + timedelta(seconds=60) - now).total_seconds()
                        if sleep_for > 0:
                            time.sleep(sleep_for + 0.1)  # small cushion
                    # after possible sleep, proceed and append timestamp after success

            msg = MIMEMultipart('alternative')
            msg['From'] = account_state['email']
            msg['To'] = to_email
            msg['Subject'] = subject

            tracking_id = str(uuid.uuid4())
            tracking_pixel = f'<img src="http://127.0.0.1:5000/track/{tracking_id}" width="1" height="1" style="display:none;">'
            html_body = body.replace('\n', '<br>') + tracking_pixel
            msg.attach(MIMEText(html_body, 'html'))

            # Attach files if any
            if attachments:
                for path in attachments:
                    try:
                        part = MIMEBase('application', "octet-stream")
                        with open(path, 'rb') as f:
                            part.set_payload(f.read())
                        encoders.encode_base64(part)
                        part.add_header('Content-Disposition', f'attachment; filename="{os.path.basename(path)}"')
                        msg.attach(part)
                    except Exception as e:
                        logger.warning(f"Attachment {path} could not be attached: {e}")

            # Open SMTP connection
            server, err = self._open_smtp(account_state, timeout=20)
            if not server:
                return False, err or "Failed to open SMTP connection"
            try:
                server.send_message(msg)
                server.quit()
            except Exception as e:
                try:
                    server.quit()
                except:
                    pass
                return False, f"Send error: {str(e)}"

            # record sent timestamp for throttle
            if self.throttle:
                with account_state['lock']:
                    account_state['sent_timestamps'].append(datetime.utcnow())

            # Log to DB (non-fatal)
            try:
                conn = sqlite3.connect('database.db')
                cursor = conn.cursor()
                cursor.execute("""
                    INSERT INTO email_log (campaign_id, email, tracking_id, sent_at) 
                    VALUES (?, ?, ?, ?)
                """, (self.campaign_id, to_email, tracking_id, datetime.now()))
                conn.commit()
                conn.close()
            except Exception:
                logger.debug("DB log failed but continuing")

            return True, None

        except Exception as e:
            logger.exception("Unexpected send error")
            return False, str(e)

    def process_campaign_ultra_fast(self, email_list, subject, body, accounts, attachments=None):
        """
        Process emails with ThreadPool, applying optional rotate and throttle.
        Each account passed in is converted into a runtime state object that keeps timestamps and lock.
        """
        try:
            self.total_emails = len(email_list)
            # create campaign record
            try:
                conn = sqlite3.connect('database.db')
                cursor = conn.cursor()
                cursor.execute("""
                    INSERT INTO campaigns (id, subject, total_emails, created_at) 
                    VALUES (?, ?, ?, ?)
                """, (self.campaign_id, subject, self.total_emails, datetime.now()))
                conn.commit()
                conn.close()
            except Exception:
                pass

            # prepare account states
            account_states = []
            for a in accounts:
                s = dict(a)
                s['smtp_port'] = int(s.get('smtp_port') or 587)
                s['use_ssl'] = bool(s.get('use_ssl', False) or s['smtp_port'] == 465)
                s['max_per_minute'] = int(s.get('max_per_minute', 60) or 60)
                s['sent_timestamps'] = []
                s['lock'] = Lock()
                account_states.append(s)

            if not account_states:
                raise Exception("No sending accounts available")

            # ThreadPoolExecutor for concurrency (moderate number of workers)
            with concurrent.futures.ThreadPoolExecutor(max_workers=8) as executor:
                futures = []
                for i, email_data in enumerate(email_list):
                    if not self.running:
                        break
                    email_addr = str(email_data.get('email', '')).strip().lower()
                    if not self.quick_validate_email(email_addr):
                        continue

                    # pick account_state either rotating or fixed first account
                    if self.rotate:
                        acct = account_states[i % len(account_states)]
                    else:
                        acct = account_states[0]

                    future = executor.submit(self.send_single_email_optimized, email_addr, subject, body, acct, attachments)
                    futures.append((future, email_addr))

                # collect results
                for i, (future, email_addr) in enumerate(futures):
                    if not self.running:
                        break
                    try:
                        success, error = future.result(timeout=30)
                        if success:
                            self.sent_count += 1
                        else:
                            self.error_count += 1
                            logger.warning(f"Email to {email_addr} failed: {error}")

                        # update progress occasionally
                        if (i + 1) % 10 == 0 or (i + 1) == len(futures):
                            progress = ((i + 1) / len(futures)) * 100 if len(futures) else 100
                            socketio.emit('progress_update', {
                                'campaign_id': self.campaign_id,
                                'progress': progress,
                                'current': i + 1,
                                'total': len(futures),
                                'sent': self.sent_count,
                                'errors': self.error_count,
                                'status': 'success' if success else 'failed'
                            })
                    except Exception as e:
                        self.error_count += 1
                        logger.exception("Future result error")
                        continue

            # final update & DB update
            socketio.emit('sending_complete', {
                'campaign_id': self.campaign_id,
                'sent': self.sent_count,
                'total': self.total_emails,
                'errors': self.error_count,
                'success_rate': (self.sent_count / self.total_emails * 100) if self.total_emails > 0 else 0
            })
            try:
                conn = sqlite3.connect('database.db')
                cursor = conn.cursor()
                cursor.execute("""
                    UPDATE campaigns 
                    SET sent_emails = ?, completed_at = ?, status = 'completed'
                    WHERE id = ?
                """, (self.sent_count, datetime.now(), self.campaign_id))
                conn.commit()
                conn.close()
            except Exception:
                pass

            logger.info(f"Campaign {self.campaign_id} finished: {self.sent_count}/{self.total_emails}")

        except Exception as e:
            logger.exception("Campaign processing error")
            socketio.emit('sending_error', {'campaign_id': self.campaign_id, 'error': str(e)})
        finally:
            active_campaigns.pop(self.campaign_id, None)


def background_email_processor():
    while True:
        try:
            job = email_queue.get(timeout=1)
            campaign_id = job['campaign_id']
            email_list = job['email_list']
            subject = job['subject']
            body = job['body']
            accounts = job['accounts']
            attachments = job.get('attachments', [])
            rotate = job.get('rotate', True)
            throttle = job.get('throttle', True)

            sender = SuperFastEmailSender(campaign_id, throttle=throttle, rotate=rotate)
            active_campaigns[campaign_id] = sender
            sender.process_campaign_ultra_fast(email_list, subject, body, accounts, attachments)
            email_queue.task_done()
        except queue.Empty:
            continue
        except Exception as e:
            logger.exception("Background worker error")

# start background worker
worker_thread = Thread(target=background_email_processor, daemon=True)
worker_thread.start()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/test-smtp', methods=['POST'])
def test_smtp():
    try:
        accounts_json = request.form.get('accounts', '[]')
        accounts = json.loads(accounts_json)
        if not accounts:
            return jsonify({'success': False, 'error': 'No accounts to test'})

        sender = SuperFastEmailSender("test")
        results = []
        for account in accounts:
            ok, msg = sender.test_smtp_connection(account)
            results.append({'email': account.get('email'), 'success': ok, 'message': msg})
        return jsonify({'success': True, 'results': results})
    except Exception as e:
        logger.exception("test-smtp error")
        return jsonify({'success': False, 'error': str(e)})

@app.route('/send-emails', methods=['POST'])
def send_emails():
    global campaign_counter
    try:
        subject = request.form.get('subject', '').strip()
        body = request.form.get('body', '').strip()
        accounts_json = request.form.get('accounts', '[]')
        rotate_flag = request.form.get('rotate', 'true').lower() == 'true'
        throttle_flag = request.form.get('throttle', 'true').lower() == 'true'

        if not subject or not body:
            return jsonify({'success': False, 'error': 'Subject and body are required'})

        accounts = json.loads(accounts_json)
        if not accounts:
            return jsonify({'success': False, 'error': 'No email accounts configured'})

        if 'file' not in request.files:
            return jsonify({'success': False, 'error': 'No email list file uploaded'})
        file = request.files['file']
        if file.filename == '':
            return jsonify({'success': False, 'error': 'No file selected'})

        os.makedirs('uploads', exist_ok=True)
        filename = f"uploads/{int(time.time())}_{file.filename}"
        file.save(filename)

        try:
            if filename.lower().endswith('.csv'):
                df = pd.read_csv(filename, usecols=[0])
            else:
                df = pd.read_excel(filename, usecols=[0])
        except Exception as e:
            return jsonify({'success': False, 'error': f'Error reading file: {str(e)}'})

        email_list = []
        for value in df.iloc[:, 0].dropna():
            email = str(value).strip().lower()
            if '@' in email and '.' in email:
                email_list.append({'email': email})

        if not email_list:
            return jsonify({'success': False, 'error': 'No valid email addresses found'})

        attachment_files = []
        if 'attachments' in request.files:
            for attachment in request.files.getlist('attachments'):
                if attachment.filename != '':
                    att_filename = f"uploads/{int(time.time())}_{attachment.filename}"
                    attachment.save(att_filename)
                    attachment_files.append(att_filename)

        campaign_counter += 1
        campaign_id = f"campaign_{campaign_counter}_{int(time.time())}"

        job = {
            'campaign_id': campaign_id,
            'email_list': email_list,
            'subject': subject,
            'body': body,
            'accounts': accounts,
            'attachments': attachment_files,
            'created_at': datetime.now().isoformat(),
            'rotate': rotate_flag,
            'throttle': throttle_flag
        }

        email_queue.put(job)

        return jsonify({
            'success': True,
            'campaign_id': campaign_id,
            'message': 'Email campaign started successfully!',
            'total_emails': len(email_list),
            'estimated_time': f"{len(email_list) // 120} minutes"
        })
    except Exception as e:
        logger.exception("send_emails error")
        return jsonify({'success': False, 'error': str(e)})

@app.route('/track/<tracking_id>')
def track_email_open(tracking_id):
    try:
        conn = sqlite3.connect('database.db')
        cursor = conn.cursor()
        cursor.execute("""
            UPDATE email_log 
            SET opened = 1, opened_at = ? 
            WHERE tracking_id = ?
        """, (datetime.now(), tracking_id))
        conn.commit()
        conn.close()

        socketio.emit('email_opened', {
            'tracking_id': tracking_id,
            'opened_at': datetime.now().isoformat()
        })
        gif_data = b'GIF89a\x01\x00\x01\x00\x80\x00\x00\xff\xff\xff\x00\x00\x00!\xf9\x04\x01\x00\x00\x00\x00,\x00\x00\x00\x00\x01\x00\x01\x00@\x02\x02\x04\x01\x00;'
        from flask import Response
        return Response(gif_data, mimetype='image/gif')
    except Exception as e:
        logger.exception("tracking error")
        return '', 200

@app.route('/campaigns')
def get_campaigns():
    try:
        conn = sqlite3.connect('database.db')
        cursor = conn.cursor()
        cursor.execute("""
            SELECT id, subject, total_emails, sent_emails, created_at, status 
            FROM campaigns 
            ORDER BY created_at DESC 
            LIMIT 10
        """)
        campaigns = cursor.fetchall()
        conn.close()
        return jsonify({
            'campaigns': [
                {
                    'id': c[0],
                    'subject': c[1],
                    'total': c[2],
                    'sent': c[3],
                    'created': c[4],
                    'status': c[5]
                } for c in campaigns
            ]
        })
    except Exception:
        return jsonify({'campaigns': []})

@app.route('/favicon.ico')
def favicon():
    return '', 204

# Stop a running campaign (attempt)
@app.route('/stop-campaign', methods=['POST'])
def stop_campaign():
    try:
        data = request.get_json() or {}
        campaign_id = data.get('campaign_id')
        if not campaign_id:
            return jsonify({'success': False, 'error': 'campaign_id required'}), 400
        sender = active_campaigns.get(campaign_id)
        if not sender:
            return jsonify({'success': False, 'error': 'Campaign not found or already finished'}), 404
        # attempt to stop gracefully
        try:
            sender.running = False
            # update DB state
            conn = sqlite3.connect('database.db')
            cursor = conn.cursor()
            cursor.execute("UPDATE campaigns SET status = 'stopped', completed_at = ? WHERE id = ?", (datetime.now(), campaign_id))
            conn.commit()
            conn.close()
        except Exception:
            pass
        return jsonify({'success': True, 'message': 'Stop signal sent'})
    except Exception as e:
        logger.exception("stop_campaign error")
        return jsonify({'success': False, 'error': str(e)}), 500

# Campaign logs endpoint
@app.route('/campaign-logs')
def campaign_logs():
    try:
        campaign_id = request.args.get('campaign_id')
        if not campaign_id:
            return jsonify({'success': False, 'error': 'campaign_id is required'}), 400
        conn = sqlite3.connect('database.db')
        cursor = conn.cursor()
        cursor.execute("""
            SELECT email, sent_at, opened, opened_at, bounced, error_message
            FROM email_log
            WHERE campaign_id = ?
            ORDER BY sent_at DESC
            LIMIT 5000
        """, (campaign_id,))
        rows = cursor.fetchall()
        conn.close()
        logs = []
        for r in rows:
            logs.append({
                'email': r[0],
                'sent_at': r[1],
                'opened': bool(r[2]),
                'opened_at': r[3],
                'bounced': bool(r[4]),
                'error_message': r[5]
            })
        return jsonify({'success': True, 'logs': logs})
    except Exception as e:
        logger.exception("campaign_logs error")
        return jsonify({'success': False, 'error': str(e)}), 500


if __name__ == '__main__':
    init_db()
    print("🚀 Lightning Email Marketing Server Starting...")
    socketio.run(app, debug=True, host='0.0.0.0', port=5000)
